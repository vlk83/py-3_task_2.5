update t_pdds set pdds_pdFile = 'CEL27922610-02A.TIF' where id_pdds=26965



select * from t_pdds where id_pdds=26965


