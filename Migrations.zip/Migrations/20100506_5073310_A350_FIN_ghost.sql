delete
from r_fin_ci 
where fin in ('3504DS','1104DS','3202JY','3204JY','3102LL','3201JG','3203JG')


