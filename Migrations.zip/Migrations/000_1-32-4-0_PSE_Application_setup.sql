truncate table application_setup

INSERT INTO APPLICATION_SETUP (
	application_program,
	application_patch,
	application_version) 
VALUES (
	'A400M',
	'5.0',
	'1.32')