DELETE FROM T_CHOICELIST where choicelist='SSPCAllocatedCardFin'
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','101XY','1' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','102XY','2' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','103XY','3' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','104XY','4' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','105XY','5' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','106XY','6' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','201XY','7' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','202XY','8' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','203XY','9' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','204XY','10' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','205XY','11' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','206XY','12' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','301XY','13' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','302XY','14' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','303XY','15' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','304XY','16' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','305XY','17' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','306XY','18' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','401XY','19' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','402XY','20' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','403XY','21' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','404XY','22' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','405XY','23' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','406XY','24' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','501XY','25' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','502XY','26' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','503XY','27' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','504XY','28' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','505XY','29' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','506XY','30' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','601XY','31' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','602XY','32' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','603XY','33' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','604XY','34' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','605XY','35' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','606XY','36' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','701XY','37' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','702XY','38' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','703XY','39' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','704XY','40' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','705XY','41' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','706XY','42' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','801XY','43' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','802XY','44' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','803XY','45' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','804XY','46' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','805XY','47' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','806XY','48' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','1101XY','49' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','1102XY','50' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','1103XY','51' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','1104XY','52' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','1105XY','53' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','1106XY','54' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','1201XY','55' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','1202XY','56' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','1203XY','57' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','1204XY','58' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','1205XY','59' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','1206XY','60' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','1301XY','61' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','1302XY','62' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','1303XY','63' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','1304XY','64' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','1305XY','65' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','1306XY','66' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','1401XY','67' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','1402XY','68' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','1403XY','69' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','1404XY','70' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','1405XY','71' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','1406XY','72' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','4101XZ','73' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','4103XZ','74' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','4105XZ','75' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','4107XZ','76' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','4109XZ','77' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','4111XZ','78' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','4113XZ','79' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','4115XZ','80' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','4117XZ','81' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','4119XZ','82' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','4121XZ','83' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','4123XZ','84' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','4125XZ','85' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','4127XZ','86' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','4129XZ','87' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','4131XZ','88' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','4202XZ','89' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','4204XZ','90' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','4206XZ','91' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','4208XZ','92' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','4210XZ','93' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','4212XZ','94' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','4214XZ','95' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','4216XZ','96' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','4218XZ','97' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','4220XZ','98' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','4222XZ','99' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','4224XZ','100' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','4226XZ','101' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','4228XZ','102' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','4230XZ','103' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','4232XZ','104' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','4101XW','105' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','4103XW','106' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','4105XW','107' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','4107XW','108' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','4202XW','109' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','4204XW','110' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','4206XW','111' 
INSERT INTO T_CHOICELIST (choicelist,choiceValue,choiceorder) SELECT 'SSPCAllocatedCardFin','4208XW','112' 













































