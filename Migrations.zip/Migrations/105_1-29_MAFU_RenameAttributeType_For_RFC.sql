	-- rename attribute Type
update infobase set object_name = 'Type EPAC – TDU' where object_value='rfc_RFCType' and object_name='Type'
