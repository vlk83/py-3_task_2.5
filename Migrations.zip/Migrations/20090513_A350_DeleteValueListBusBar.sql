-- Delete the values of the Busbar list 
DELETE FROM T_CHOICELIST WHERE choicelist = 'Busbar' AND ChoiceValue='181XP'
DELETE FROM T_CHOICELIST WHERE choicelist = 'Busbar' AND ChoiceValue='183XP'
DELETE FROM T_CHOICELIST WHERE choicelist = 'Busbar' AND ChoiceValue='282XP'
DELETE FROM T_CHOICELIST WHERE choicelist = 'Busbar' AND ChoiceValue='284XP'