UPDATE 
	APPLICATION_SETUP
SET
	application_patch = '0.0',
	application_version = '2.1'